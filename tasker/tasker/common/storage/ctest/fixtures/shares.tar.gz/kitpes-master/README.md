# Kitpes

<img src="https://upload.wikimedia.org/wikipedia/en/6/64/CatDog.jpeg" />


Cat or dog? What it is? Train your model and be always able to tell!

```
pipenv install
pipenv shell
python3 ./train.py
python3 ./validate.py ~/Downloads/cat.jpg
```

It's better to provide square images. They can be easily [found using Google Advanced Search](https://www.google.com/search?as_st=y&tbs=iar%3As&tbm=isch&sxsrf=ACYBGNQlECoXhBTXMi7yczmwwLqghG8mHw%3A1574087190600&sa=1&ei=FqrSXbOrJIXnsAer47SwBQ&q=cute+AND+%28cat+OR+dog%29&oq=cute+AND+%28cat+OR+dog%29&gs_l=img.3...12802.13321..13469...0.0..0.253.415.0j1j1......0....1..gws-wiz-img.hwpKo2W_JOI&ved=0ahUKEwizjt3e-_PlAhWFM-wKHasxDVYQ4dUDCAc&uact=5).